import "./styles/style.scss";

import "./js/app";

console.log("Travel App Loaded!");
