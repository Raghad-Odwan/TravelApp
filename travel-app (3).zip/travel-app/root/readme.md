# 🚀 Travel App

A simple Webpack + Node.js + Express.js setup for a travel application.

## 📌 Features
- Webpack bundling
- Express.js server
- SCSS support
- Babel transpiling
- Environment variables using dotenv

## 📥 Installation
1. Clone this repository:
   ```sh
   git clone https://github.com/RAGHDODWAN/ourusername/travel-app.git
   cd travel-app
   Install dependencies:
npm install
Start the development server:
npm run dev
Build for production:
npm run build
Start the Express server:
npm start
🛠 Tech Stack
Node.js
Express.js
Webpack
Babel
SCSS
📜 License
This project is licensed under the MIT License
## Requirements
- Node.js version 22.13.1 or later is required to run this project.
