// استيراد أنماط CSS (إذا كنت تستخدم Webpack)
import "../styles/style.scss";
console.log("app.js is loaded!");
// دالة لتحديث واجهة المستخدم
const updateUI = (data) => {
    document.getElementById("destination").innerText = `Destination: ${data.city}`;
    document.getElementById("weather").innerText = `Weather: ${data.weather}`;
};

// جلب البيانات من السيرفر عند الضغط على زر
document.getElementById("fetch-data").addEventListener("click", async () => {
    try {
        const res = await fetch("http://localhost:3000/data");
        const data = await res.json();
        updateUI(data);
    } catch (error) {
        console.error("Error fetching data:", error);
    }
});

console.log("App.js loaded successfully!");
